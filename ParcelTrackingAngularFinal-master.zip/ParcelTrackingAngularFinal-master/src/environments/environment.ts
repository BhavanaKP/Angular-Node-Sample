export const environment = {
  production: false,
  baseUrl: 'http://localhost:5002/'
};
